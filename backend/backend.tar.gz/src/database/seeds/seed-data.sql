-- Initial seed data for a minimal working environment
-- Creates one tenant and one admin user with a known password hash
-- Password: Test123456 (bcrypt, cost 12)

WITH t AS (
  INSERT INTO tenants (name, slug, "companyName", "taxNumber", email, phone, address, "subscriptionPlan", status)
  VALUES ('Demo Şirket 1', 'demo-sirket-1', 'Demo Ticaret A.Ş.', '1234567890', 'demo1@test.com', '+90 555 111 2233', 'İstanbul, Türkiye', 'professional', 'active')
  ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name
  RETURNING id
)
INSERT INTO users (email, password, "firstName", "lastName", role, "isActive", "tenantId")
SELECT 'admin@test.com', '$2b$12$p8xHBFrTlPYegi6gSdMNPOB41Tp3q0xvnW1ylw9Bk.wEKNfkC/dp.', 'Admin', 'User', 'tenant_admin', true, t.id
FROM t
ON CONFLICT (email) DO UPDATE SET password = EXCLUDED.password;
