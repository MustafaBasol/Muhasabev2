import { SetMetadata } from '@nestjs/common';
import type { UserRole } from '../../users/entities/user.entity';

export const ROLES_KEY = 'roles';
export const Roles = (...roles: UserRole[]) =>
  SetMetadata<string, UserRole[]>(ROLES_KEY, roles);
