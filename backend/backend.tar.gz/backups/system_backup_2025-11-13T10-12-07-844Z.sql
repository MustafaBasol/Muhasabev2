--
-- PostgreSQL database dump
--

\restrict A1GWb3khMnmHLHh2y9x88jAOiw66DwyU2cwJCdmD5QaU4ZJVur2gtIW9fGicSIK

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: expenses_category_enum; Type: TYPE; Schema: public; Owner: moneyflow
--

CREATE TYPE public.expenses_category_enum AS ENUM (
    'other',
    'rent',
    'utilities',
    'salaries',
    'personnel',
    'supplies',
    'equipment',
    'marketing',
    'travel',
    'insurance',
    'taxes'
);


ALTER TYPE public.expenses_category_enum OWNER TO moneyflow;

--
-- Name: expenses_status_enum; Type: TYPE; Schema: public; Owner: moneyflow
--

CREATE TYPE public.expenses_status_enum AS ENUM (
    'pending',
    'approved',
    'paid',
    'rejected'
);


ALTER TYPE public.expenses_status_enum OWNER TO moneyflow;

--
-- Name: invoices_status_enum; Type: TYPE; Schema: public; Owner: moneyflow
--

CREATE TYPE public.invoices_status_enum AS ENUM (
    'draft',
    'sent',
    'paid',
    'overdue',
    'cancelled'
);


ALTER TYPE public.invoices_status_enum OWNER TO moneyflow;

--
-- Name: plan_enum; Type: TYPE; Schema: public; Owner: moneyflow
--

CREATE TYPE public.plan_enum AS ENUM (
    'STARTER',
    'PRO',
    'BUSINESS'
);


ALTER TYPE public.plan_enum OWNER TO moneyflow;

--
-- Name: role_enum; Type: TYPE; Schema: public; Owner: moneyflow
--

CREATE TYPE public.role_enum AS ENUM (
    'OWNER',
    'ADMIN',
    'MEMBER'
);


ALTER TYPE public.role_enum OWNER TO moneyflow;

--
-- Name: tenants_status_enum; Type: TYPE; Schema: public; Owner: moneyflow
--

CREATE TYPE public.tenants_status_enum AS ENUM (
    'active',
    'suspended',
    'trial',
    'expired'
);


ALTER TYPE public.tenants_status_enum OWNER TO moneyflow;

--
-- Name: tenants_subscriptionplan_enum; Type: TYPE; Schema: public; Owner: moneyflow
--

CREATE TYPE public.tenants_subscriptionplan_enum AS ENUM (
    'free',
    'basic',
    'professional',
    'enterprise'
);


ALTER TYPE public.tenants_subscriptionplan_enum OWNER TO moneyflow;

--
-- Name: users_role_enum; Type: TYPE; Schema: public; Owner: moneyflow
--

CREATE TYPE public.users_role_enum AS ENUM (
    'super_admin',
    'tenant_admin',
    'accountant',
    'user'
);


ALTER TYPE public.users_role_enum OWNER TO moneyflow;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "userId" uuid,
    "tenantId" uuid NOT NULL,
    entity character varying(100) NOT NULL,
    "entityId" uuid,
    action character varying(20) NOT NULL,
    diff jsonb,
    ip character varying(45),
    "userAgent" text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_log OWNER TO moneyflow;

--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.bank_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "tenantId" uuid NOT NULL,
    name character varying(150) NOT NULL,
    iban character varying(34) NOT NULL,
    "bankName" character varying(100),
    currency character varying(3) DEFAULT 'TRY'::character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.bank_accounts OWNER TO moneyflow;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.customers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    email character varying,
    phone character varying,
    address text,
    "taxNumber" character varying,
    company character varying,
    balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    "tenantId" uuid NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.customers OWNER TO moneyflow;

--
-- Name: email_outbox; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.email_outbox (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "to" character varying(320) NOT NULL,
    subject character varying(255) NOT NULL,
    provider character varying(32) NOT NULL,
    success boolean DEFAULT false NOT NULL,
    "messageId" character varying(64),
    "correlationId" character varying(64),
    "userId" character varying(64),
    "tenantId" character varying(64),
    "tokenId" character varying(64),
    type character varying(32),
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_outbox OWNER TO moneyflow;

--
-- Name: email_suppression; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.email_suppression (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(320) NOT NULL,
    reason character varying(50),
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_suppression OWNER TO moneyflow;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "userId" uuid NOT NULL,
    "tokenHash" character varying(128) NOT NULL,
    "expiresAt" timestamp without time zone NOT NULL,
    "usedAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    ip character varying(45),
    ua text
);


ALTER TABLE public.email_verification_tokens OWNER TO moneyflow;

--
-- Name: expenses; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.expenses (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "expenseNumber" character varying NOT NULL,
    "tenantId" uuid NOT NULL,
    "supplierId" uuid,
    description character varying NOT NULL,
    "expenseDate" date NOT NULL,
    amount numeric(10,2) NOT NULL,
    category public.expenses_category_enum DEFAULT 'other'::public.expenses_category_enum NOT NULL,
    status public.expenses_status_enum DEFAULT 'pending'::public.expenses_status_enum NOT NULL,
    notes text,
    "receiptUrl" character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    is_voided boolean DEFAULT false,
    void_reason text,
    voided_at timestamp without time zone,
    voided_by uuid
);


ALTER TABLE public.expenses OWNER TO moneyflow;

--
-- Name: fiscal_periods; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.fiscal_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "tenantId" uuid NOT NULL,
    name character varying NOT NULL,
    "periodStart" date NOT NULL,
    "periodEnd" date NOT NULL,
    "isLocked" boolean DEFAULT false NOT NULL,
    "lockedAt" timestamp without time zone,
    "lockedBy" uuid,
    "lockReason" text,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fiscal_periods OWNER TO moneyflow;

--
-- Name: invites; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.invites (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "organizationId" uuid NOT NULL,
    email character varying NOT NULL,
    role public.role_enum DEFAULT 'MEMBER'::public.role_enum NOT NULL,
    token character varying NOT NULL,
    "expiresAt" timestamp without time zone NOT NULL,
    "acceptedAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.invites OWNER TO moneyflow;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "invoiceNumber" character varying NOT NULL,
    "tenantId" uuid NOT NULL,
    "customerId" uuid,
    "issueDate" date NOT NULL,
    "dueDate" date NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "taxAmount" numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    "discountAmount" numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total numeric(10,2) NOT NULL,
    status public.invoices_status_enum DEFAULT 'draft'::public.invoices_status_enum NOT NULL,
    notes text,
    "saleId" character varying,
    type character varying,
    "refundedInvoiceId" uuid,
    items jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    is_voided boolean DEFAULT false,
    void_reason text,
    voided_at timestamp without time zone,
    voided_by uuid
);


ALTER TABLE public.invoices OWNER TO moneyflow;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO moneyflow;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: moneyflow
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO moneyflow;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: moneyflow
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: organization_members; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.organization_members (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "organizationId" uuid NOT NULL,
    "userId" uuid NOT NULL,
    role public.role_enum DEFAULT 'MEMBER'::public.role_enum NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.organization_members OWNER TO moneyflow;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.organizations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    plan public.plan_enum DEFAULT 'STARTER'::public.plan_enum NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.organizations OWNER TO moneyflow;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "userId" uuid NOT NULL,
    "tokenHash" character varying(128) NOT NULL,
    "expiresAt" timestamp without time zone NOT NULL,
    "usedAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    ip character varying(45),
    ua text
);


ALTER TABLE public.password_reset_tokens OWNER TO moneyflow;

--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    "taxRate" numeric(5,2) DEFAULT '18'::numeric NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" uuid NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "parentId" character varying,
    "isProtected" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.product_categories OWNER TO moneyflow;

--
-- Name: products; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    code character varying NOT NULL,
    description text,
    price numeric(15,2) NOT NULL,
    cost numeric(15,2),
    stock numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    "minStock" numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    unit character varying DEFAULT 'pieces'::character varying NOT NULL,
    category character varying,
    barcode character varying,
    "taxRate" numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    "categoryTaxRateOverride" numeric(5,2),
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" uuid NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.products OWNER TO moneyflow;

--
-- Name: COLUMN products."categoryTaxRateOverride"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.products."categoryTaxRateOverride" IS 'Ürüne özel KDV oranı - Kategorinin varsayılan KDV oranını geçersiz kılar';


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.quotes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "publicId" uuid DEFAULT gen_random_uuid() NOT NULL,
    "quoteNumber" character varying(32) NOT NULL,
    "tenantId" uuid NOT NULL,
    "customerId" uuid,
    "customerName" character varying(255),
    "issueDate" date NOT NULL,
    "validUntil" date,
    currency character varying(3) DEFAULT 'TRY'::character varying NOT NULL,
    total numeric(12,2) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    items jsonb,
    "scopeOfWorkHtml" text,
    version integer DEFAULT 1 NOT NULL,
    revisions jsonb,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.quotes OWNER TO moneyflow;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.sales (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "tenantId" uuid NOT NULL,
    "customerId" uuid,
    "saleDate" date NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "taxAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "discountAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'created'::character varying NOT NULL,
    "sourceQuoteId" character varying,
    "invoiceId" uuid,
    items jsonb,
    notes text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "saleNumber" character varying(32) NOT NULL
);


ALTER TABLE public.sales OWNER TO moneyflow;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.suppliers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    email character varying,
    phone character varying,
    address text,
    "taxNumber" character varying,
    company character varying,
    balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    "tenantId" uuid NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.suppliers OWNER TO moneyflow;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    "companyName" character varying,
    "taxNumber" character varying,
    address character varying,
    phone character varying,
    email character varying,
    "subscriptionPlan" public.tenants_subscriptionplan_enum DEFAULT 'free'::public.tenants_subscriptionplan_enum NOT NULL,
    status public.tenants_status_enum DEFAULT 'trial'::public.tenants_status_enum NOT NULL,
    "subscriptionExpiresAt" timestamp without time zone,
    "maxUsers" integer DEFAULT 5 NOT NULL,
    settings jsonb,
    features jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    website character varying,
    "taxOffice" character varying,
    "mersisNumber" character varying,
    "kepAddress" character varying,
    "siretNumber" character varying,
    "sirenNumber" character varying,
    "apeCode" character varying,
    "tvaNumber" character varying,
    "rcsNumber" character varying,
    steuernummer character varying,
    "umsatzsteuerID" character varying,
    handelsregisternummer character varying,
    finanzamt character varying,
    "einNumber" character varying,
    "taxIDNumber" character varying,
    "businessLicense" character varying,
    "salesTaxNumber" character varying,
    "cancelAtPeriodEnd" boolean DEFAULT false,
    "stripeCustomerId" character varying(255),
    "stripeSubscriptionId" character varying(255),
    "billingInterval" character varying(16),
    geschaeftsfuehrer character varying,
    "taxId" character varying,
    "businessLicenseNumber" character varying,
    "stateOfIncorporation" character varying
);


ALTER TABLE public.tenants OWNER TO moneyflow;

--
-- Name: COLUMN tenants.website; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants.website IS 'Website URL';


--
-- Name: COLUMN tenants."taxOffice"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."taxOffice" IS 'Vergi Dairesi';


--
-- Name: COLUMN tenants."mersisNumber"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."mersisNumber" IS 'Mersis Numarası';


--
-- Name: COLUMN tenants."kepAddress"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."kepAddress" IS 'KEP Adresi (e-fatura)';


--
-- Name: COLUMN tenants."siretNumber"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."siretNumber" IS 'SIRET Numarası (14 haneli)';


--
-- Name: COLUMN tenants."sirenNumber"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."sirenNumber" IS 'SIREN Numarası (9 haneli)';


--
-- Name: COLUMN tenants."apeCode"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."apeCode" IS 'APE/NAF Kodu (ana faaliyet)';


--
-- Name: COLUMN tenants."tvaNumber"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."tvaNumber" IS 'TVA Numarası (FR + 11 hane)';


--
-- Name: COLUMN tenants."rcsNumber"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."rcsNumber" IS 'RCS Numarası (Ticaret Sicil)';


--
-- Name: COLUMN tenants.steuernummer; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants.steuernummer IS 'Steuernummer (Vergi Numarası)';


--
-- Name: COLUMN tenants."umsatzsteuerID"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."umsatzsteuerID" IS 'Umsatzsteuer-ID (DE + 9 hane)';


--
-- Name: COLUMN tenants.handelsregisternummer; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants.handelsregisternummer IS 'Handelsregisternummer (Ticaret Sicil No)';


--
-- Name: COLUMN tenants.finanzamt; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants.finanzamt IS 'Finanzamt (Vergi Dairesi)';


--
-- Name: COLUMN tenants."einNumber"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."einNumber" IS 'EIN Numarası (Employer Identification Number)';


--
-- Name: COLUMN tenants."taxIDNumber"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."taxIDNumber" IS 'Tax ID Numarası';


--
-- Name: COLUMN tenants."businessLicense"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."businessLicense" IS 'Business License Number';


--
-- Name: COLUMN tenants."salesTaxNumber"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."salesTaxNumber" IS 'Sales Tax Number';


--
-- Name: COLUMN tenants."billingInterval"; Type: COMMENT; Schema: public; Owner: moneyflow
--

COMMENT ON COLUMN public.tenants."billingInterval" IS 'billing interval: month|year';


--
-- Name: users; Type: TABLE; Schema: public; Owner: moneyflow
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    "firstName" character varying NOT NULL,
    "lastName" character varying NOT NULL,
    role public.users_role_enum DEFAULT 'user'::public.users_role_enum NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLoginAt" timestamp without time zone,
    "tenantId" uuid NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deletionRequestedAt" timestamp without time zone,
    "isPendingDeletion" boolean DEFAULT false NOT NULL,
    "currentOrgId" uuid,
    twofactorsecret character varying,
    twofactorenabled boolean DEFAULT false,
    backupcodes text[],
    twofactorenabledat timestamp without time zone,
    "twoFactorSecret" character varying(255),
    "isTwoFactorEnabled" boolean DEFAULT false,
    "twoFactorBackupCodes" text[],
    "twoFactorEnabled" boolean DEFAULT false,
    "twoFactorEnabledAt" timestamp without time zone,
    "isEmailVerified" boolean DEFAULT false NOT NULL,
    "emailVerificationToken" character varying,
    "emailVerificationSentAt" timestamp without time zone,
    "emailVerifiedAt" timestamp without time zone,
    "passwordResetToken" character varying,
    "passwordResetExpiresAt" timestamp without time zone,
    "notificationPreferences" jsonb
);


ALTER TABLE public.users OWNER TO moneyflow;

--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.audit_log (id, "userId", "tenantId", entity, "entityId", action, diff, ip, "userAgent", "createdAt") FROM stdin;
9aa4f26e-52a6-4bae-afab-05e39fffaf20	f66c54d8-5b5c-4b7f-b5ed-fc00251cf7e7	1c3e8b69-4796-4362-a71f-fec03308dbe4	Customer	30b79a92-4865-4545-aff3-8e61659d65ff	CREATE	{"created": {"id": "30b79a92-4865-4545-aff3-8e61659d65ff", "name": "Test Customer Audit", "email": "au***@test.com", "phone": "55***", "address": null, "balance": "0.00", "company": null, "tenantId": "1c3e8b69-4796-4362-a71f-fec03308dbe4", "createdAt": {}, "taxNumber": null, "updatedAt": {}}}	127.0.0.1	curl/8.5.0	2025-10-30 12:24:24.893427
31b82818-48f7-4f56-934e-4a0b04f961cb	f66c54d8-5b5c-4b7f-b5ed-fc00251cf7e7	1c3e8b69-4796-4362-a71f-fec03308dbe4	Customer	a62a9eb0-e9f7-408d-89bf-a003eab5e871	CREATE	{"created": {"id": "a62a9eb0-e9f7-408d-89bf-a003eab5e871", "name": "Debug Customer", "email": "de***@test.com", "phone": "55***", "address": null, "balance": "0.00", "company": null, "tenantId": "1c3e8b69-4796-4362-a71f-fec03308dbe4", "createdAt": {}, "taxNumber": null, "updatedAt": {}}}	127.0.0.1	curl/8.5.0	2025-10-30 12:26:40.006443
f787450a-c8fc-431a-9333-fef5503d3f3b	f66c54d8-5b5c-4b7f-b5ed-fc00251cf7e7	1c3e8b69-4796-4362-a71f-fec03308dbe4	Customer	7e2bcef8-6b89-4f64-8a18-4e6a659c6375	CREATE	{"created": {"id": "7e2bcef8-6b89-4f64-8a18-4e6a659c6375", "name": "Audit Debug Customer", "email": "au***@test.com", "phone": "55***", "address": null, "balance": "0.00", "company": null, "tenantId": "1c3e8b69-4796-4362-a71f-fec03308dbe4", "createdAt": {}, "taxNumber": null, "updatedAt": {}}}	127.0.0.1	curl/8.5.0	2025-10-30 12:27:14.295889
e956b642-1036-4cb5-80a7-4635e65e9f88	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Product	e1d9a9ed-39d1-4fa4-8bf8-4a371f396512	UPDATE	{"created": {"id": "e1d9a9ed-39d1-4fa4-8bf8-4a371f396512", "code": "1451s", "cost": "0.00", "name": "makarna", "unit": "adet", "price": "100.00", "stock": "999.00", "barcode": null, "taxRate": "10.00", "category": "gıda", "isActive": true, "minStock": "10.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "updatedAt": {}, "description": null, "categoryTaxRateOverride": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-30 13:25:03.866874
0d602ef5-1370-406c-a434-1e482e2d7d1f	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Invoice	6a1f7999-7faf-48d4-acf2-5a72cfa0e48e	CREATE	{"created": {"id": "6a1f7999-7faf-48d4-acf2-5a72cfa0e48e", "type": "product", "items": [{"total": 10, "taxRate": 10, "quantity": 1, "productId": "22146672-c8b5-486d-96b2-36df5110278f", "unitPrice": 10, "description": "ekmek", "productName": "ekmek"}], "notes": "", "total": "11.00", "saleId": null, "status": "draft", "dueDate": "2025-11-29", "customer": {"id": "1a46b604-da1a-4f10-b312-6ca38b4c26a4", "name": "muhsin", "email": "ba***@gmail.com", "phone": "+9***", "address": "Esenler mah. Adnan Menderes cad.\\nGülevler sitesi No:9 Daire:11", "balance": "0.00", "company": null, "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "taxNumber": null, "updatedAt": {}}, "isVoided": false, "subtotal": "10.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "voidedAt": null, "voidedBy": null, "createdAt": {}, "issueDate": "2025-10-30", "taxAmount": "1.00", "updatedAt": {}, "customerId": "1a46b604-da1a-4f10-b312-6ca38b4c26a4", "voidReason": null, "invoiceNumber": "INV-2025-10-009", "discountAmount": "0.00", "refundedInvoiceId": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-30 14:51:55.151081
cbacb2da-9db1-4ef5-b13e-e4deffdf46f8	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Product	22146672-c8b5-486d-96b2-36df5110278f	UPDATE	{"created": {"id": "22146672-c8b5-486d-96b2-36df5110278f", "code": "145", "cost": "0.00", "name": "ekmek", "unit": "adet", "price": "10.00", "stock": "99.00", "barcode": null, "taxRate": "10.00", "category": "gıda", "isActive": true, "minStock": "10.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "updatedAt": {}, "description": null, "categoryTaxRateOverride": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-30 14:51:55.30772
5e1e1332-8f59-4d76-aa9c-a7c1607d3435	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Invoice	f8e9690b-ddfb-4a25-825d-2ddf22cc1753	UPDATE	{"created": {"id": "f8e9690b-ddfb-4a25-825d-2ddf22cc1753", "type": "product", "items": [{"total": 300, "taxRate": 10, "quantity": 3, "productId": "b7f07883-d918-4392-b010-8d5417dce08f", "unitPrice": 100, "description": "pasta", "productName": "pasta"}], "notes": "Bu fatura SAL-2025-10-001 numaralı satıştan oluşturulmuştur.", "total": "330.00", "saleId": "1761738362601", "status": "sent", "dueDate": "2025-11-28", "customer": {"id": "100fe332-c9db-469a-8613-9dc982e86a40", "name": "Ali Beyaz", "email": "al***@example.com", "phone": "+9***", "address": "İzmir", "balance": "0.00", "company": "Beyaz Tic.", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "taxNumber": "3333333333", "updatedAt": {}}, "isVoided": true, "subtotal": "300.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "voidedAt": {}, "voidedBy": null, "createdAt": {}, "issueDate": "2025-10-29", "taxAmount": "30.00", "updatedAt": {}, "customerId": "100fe332-c9db-469a-8613-9dc982e86a40", "voidReason": "deneme", "voidedByUser": null, "invoiceNumber": "INV-2025-10-008", "discountAmount": "0.00", "refundedInvoiceId": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-30 17:41:25.985227
9e563e93-2612-40a9-ac63-2164f44585ea	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Invoice	f8e9690b-ddfb-4a25-825d-2ddf22cc1753	UPDATE	{"created": {"id": "f8e9690b-ddfb-4a25-825d-2ddf22cc1753", "type": "product", "items": [{"total": 300, "taxRate": 10, "quantity": 3, "productId": "b7f07883-d918-4392-b010-8d5417dce08f", "unitPrice": 100, "description": "pasta", "productName": "pasta"}], "notes": "Bu fatura SAL-2025-10-001 numaralı satıştan oluşturulmuştur.", "total": "330.00", "saleId": "1761738362601", "status": "sent", "dueDate": "2025-11-28", "customer": {"id": "100fe332-c9db-469a-8613-9dc982e86a40", "name": "Ali Beyaz", "email": "al***@example.com", "phone": "+9***", "address": "İzmir", "balance": "0.00", "company": "Beyaz Tic.", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "taxNumber": "3333333333", "updatedAt": {}}, "isVoided": false, "subtotal": "300.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "voidedAt": null, "voidedBy": null, "createdAt": {}, "issueDate": "2025-10-29", "taxAmount": "30.00", "updatedAt": {}, "customerId": "100fe332-c9db-469a-8613-9dc982e86a40", "voidReason": null, "voidedByUser": null, "invoiceNumber": "INV-2025-10-008", "discountAmount": "0.00", "refundedInvoiceId": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-30 17:42:03.062198
f5bf1631-5bc9-4640-b3d0-9a183088c278	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "logs", "category": "audit_log", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:40:00.747767
f2f44e5a-8062-4aa1-b5ae-1ae558e3b37c	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "backups", "category": "backups", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:40:00.757817
66b0c715-c37b-4f6d-b229-f8064674c4de	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "account_basic", "category": "customers", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:41:24.867292
4dec515d-ec1b-40e4-8770-4f2881023863	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "account_basic", "category": "suppliers", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:41:24.875925
d9e16bb5-1d09-4b17-82cf-211a5feb85e8	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "account_basic", "category": "products", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:41:24.879315
01ea5dd5-7692-4d1c-a26a-7bf13e3513f0	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "logs", "category": "audit_log", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 1}	system	data-retention-job	2025-10-30 18:41:24.882833
4a55f814-59d7-4c08-8c06-c2267183e5d9	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "backups", "category": "backups", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:41:24.88596
b990f667-b759-4846-bc9c-82214c365590	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": false, "errors": [], "policy": "account_basic", "category": "customers", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:41:33.072017
e5c4388b-40fc-4310-b918-9c3ba2925069	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": false, "errors": [], "policy": "account_basic", "category": "suppliers", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:41:33.081426
1097614c-3c19-4ce6-8837-7c46c12cc8ae	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": false, "errors": [], "policy": "account_basic", "category": "products", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:41:33.08543
a4e35790-2da9-406a-9919-8002927c37b8	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": false, "errors": [], "policy": "logs", "category": "audit_log", "purgedRecords": 1, "skippedRecords": 0, "eligibleRecords": 1}	system	data-retention-job	2025-10-30 18:41:33.088828
f357eed9-d4eb-45c4-bf2e-ae80b1191020	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": false, "errors": [], "policy": "backups", "category": "backups", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 18:41:33.091653
6e326efc-95e5-4c39-aaa9-d61b14cc197e	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Product	e1d9a9ed-39d1-4fa4-8bf8-4a371f396512	UPDATE	{"created": {"id": "e1d9a9ed-39d1-4fa4-8bf8-4a371f396512", "code": "1451s", "cost": "0.00", "name": "makarna", "unit": "adet", "price": "100.00", "stock": "994.00", "barcode": null, "taxRate": "10.00", "category": "gıda", "isActive": true, "minStock": "10.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "updatedAt": {}, "description": null, "categoryTaxRateOverride": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-30 19:08:07.150168
b24937fa-9724-4a60-93a7-77c6272bc3e1	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Invoice	bcbc1120-09e6-4ff2-9302-fcdaecab82c6	CREATE	{"created": {"id": "bcbc1120-09e6-4ff2-9302-fcdaecab82c6", "type": "product", "items": [{"total": 500, "taxRate": 10, "quantity": 5, "productId": "e1d9a9ed-39d1-4fa4-8bf8-4a371f396512", "unitPrice": 100, "description": "makarna", "productName": "makarna"}], "notes": "Bu fatura SAL-2025-10-001 numaralı satıştan oluşturulmuştur.", "total": "550.00", "saleId": "1761851287837", "status": "sent", "dueDate": "2025-11-29", "customer": {"id": "1a46b604-da1a-4f10-b312-6ca38b4c26a4", "name": "muhsin", "email": "ba***@gmail.com", "phone": "+9***", "address": "Esenler mah. Adnan Menderes cad.\\nGülevler sitesi No:9 Daire:11", "balance": "0.00", "company": null, "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "taxNumber": null, "updatedAt": {}}, "isVoided": false, "subtotal": "500.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "voidedAt": null, "voidedBy": null, "createdAt": {}, "issueDate": "2025-10-30", "taxAmount": "50.00", "updatedAt": {}, "customerId": "1a46b604-da1a-4f10-b312-6ca38b4c26a4", "voidReason": null, "invoiceNumber": "INV-2025-10-010", "discountAmount": "0.00", "refundedInvoiceId": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-30 19:08:12.281151
496bb4b8-de8f-4a38-8183-c8623d20250a	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "logs", "category": "audit_log", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 20:23:02.789697
39a48431-bb98-4d57-93bf-f4fb12acab9a	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "backups", "category": "backups", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 20:23:02.797945
41287b42-9ab1-49e3-9956-a99ef1899cf8	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": false, "errors": [], "policy": "logs", "category": "audit_log", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 20:32:53.255318
131a4585-f4bc-44cd-bb51-6cce38cd1be1	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": false, "errors": [], "policy": "backups", "category": "backups", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 20:32:53.263248
0ee2ce16-1187-4e46-92f0-4bda025ab8ff	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "logs", "category": "audit_log", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 20:33:40.206092
cb439e3a-91d3-4f37-a317-6329fb14f83d	\N	02049c38-8a12-4ccd-8e44-a9d798a191ae	data_retention	\N	DELETE	{"dryRun": true, "errors": [], "policy": "backups", "category": "backups", "purgedRecords": 0, "skippedRecords": 0, "eligibleRecords": 0}	system	data-retention-job	2025-10-30 20:33:40.214374
0e8bda32-8729-4931-99ba-c5e93309a6ca	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Invoice	8e777d5c-07d8-44f5-bcd7-6233929ab3a6	CREATE	{"created": {"id": "8e777d5c-07d8-44f5-bcd7-6233929ab3a6", "type": "product", "items": [{"total": 50, "taxRate": 10, "quantity": 5, "productId": "22146672-c8b5-486d-96b2-36df5110278f", "unitPrice": 10, "description": "ekmek", "productName": "ekmek"}], "notes": "", "total": "55.00", "saleId": null, "status": "paid", "dueDate": "2025-11-30", "customer": {"id": "ab3007bb-41ab-4fac-ad15-78f2bee3a27d", "name": "mesut", "email": "ba***@gmail.com", "phone": "+9***", "address": "Esenler mah. Adnan Menderes cad.\\nGülevler sitesi No:9 Daire:11", "balance": "0.00", "company": null, "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "taxNumber": null, "updatedAt": {}}, "isVoided": false, "subtotal": "50.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "voidedAt": null, "voidedBy": null, "createdAt": {}, "issueDate": "2025-10-31", "taxAmount": "5.00", "updatedAt": {}, "customerId": "ab3007bb-41ab-4fac-ad15-78f2bee3a27d", "voidReason": null, "invoiceNumber": "INV-2025-10-011", "discountAmount": "0.00", "refundedInvoiceId": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-31 14:40:21.92482
f5b2f701-8ed5-4e2d-8525-fed5d176ae72	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Product	22146672-c8b5-486d-96b2-36df5110278f	UPDATE	{"created": {"id": "22146672-c8b5-486d-96b2-36df5110278f", "code": "145", "cost": "0.00", "name": "ekmek", "unit": "adet", "price": "10.00", "stock": "94.00", "barcode": null, "taxRate": "10.00", "category": "gıda", "isActive": true, "minStock": "10.00", "tenantId": "e2dedaf4-2605-4614-8dda-d8745d19d214", "createdAt": {}, "updatedAt": {}, "description": null, "categoryTaxRateOverride": null}}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-31 14:40:22.374911
85db7380-7d22-4d01-b95d-7da53fedeca3	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Expense	3c7b9996-6cf3-490e-a35b-42acd31c45fa	DELETE	{"deleted": true}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-01 13:45:53.543855
38e230df-f18b-4d65-b55a-099c0ae9bbe0	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	e2dedaf4-2605-4614-8dda-d8745d19d214	Invoice	cc4baf5c-fe92-4649-b025-8d31db98f950	DELETE	{"deleted": true}	91.171.134.222	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-01 13:46:53.147914
6b898788-5be3-46c6-9dfb-dbeebf458418	ebc179cf-e019-465c-a050-bf47e8b0ac3d	b73f26c7-494d-46f7-8f01-835dde396010	auth	\N	CREATE	{"email": "ba***@gmail.com", "event": "signup"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-13 06:34:19.799988
139a4679-35fb-4584-901d-780de95df932	\N	26d00eab-d879-48cc-ad09-fb60d63f3696	user	11d0948a-b49a-4783-93c8-df5135d637f9	DELETE	{"hard": true}	\N	\N	2025-11-13 10:11:22.19711
d49209af-8eb9-4a5c-b7f2-15023ccce833	\N	7acc12f9-0d05-4290-9a2b-49f0cdc8cad8	user	866e1974-3db7-46e9-bd98-17aafea08b14	DELETE	{"hard": true}	\N	\N	2025-11-13 10:11:33.794284
38d4e2ef-484d-404d-bc00-89bb8fc34bad	\N	7520e2ea-2f37-4b0b-8591-4a79c31b8af1	user	afe6f746-b1d7-4dd4-ac25-7321250886ea	DELETE	{"hard": true}	\N	\N	2025-11-13 10:11:38.419198
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.bank_accounts (id, "tenantId", name, iban, "bankName", currency, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.customers (id, name, email, phone, address, "taxNumber", company, balance, "tenantId", "createdAt", "updatedAt") FROM stdin;
7dabfdde-8711-4c41-a062-db3bfdaf49c0	Ahmet Çelik	ahmet@example.com	+90 555 111 2233	İstanbul	1111111111	Çelik Ltd.	5000.00	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.651848	2025-10-27 09:13:24.651848
9d565653-ad14-4539-bb57-94e93af0be91	Fatma Kara	fatma@example.com	+90 555 222 3344	Ankara	2222222222	Kara A.Ş.	3000.00	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.651848	2025-10-27 09:13:24.651848
100fe332-c9db-469a-8613-9dc982e86a40	Ali Beyaz	ali@example.com	+90 555 333 4455	İzmir	3333333333	Beyaz Tic.	0.00	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 09:13:24.651848	2025-10-27 09:13:24.651848
23496303-4de4-4b31-8452-6879cd5cb06d	John Doe	john@example.com	555-123-4567	123 Main St	Country	City	0.00	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-29 17:10:45.502164	2025-10-29 17:10:45.502164
79042b06-e11b-4fee-bf0e-a5180881d81f	Jane Smith	jane@company.com	555-987-6543	456 Oak Ave	Country	City	0.00	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-29 17:10:45.773219	2025-10-29 17:10:45.773219
ab3007bb-41ab-4fac-ad15-78f2bee3a27d	mesut	basol17@gmail.com	+905397444722	Esenler mah. Adnan Menderes cad.\nGülevler sitesi No:9 Daire:11	\N	\N	0.00	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-30 12:00:14.069228	2025-10-30 12:00:14.069228
30b79a92-4865-4545-aff3-8e61659d65ff	Test Customer Audit	audit@test.com	555-9999	\N	\N	\N	0.00	1c3e8b69-4796-4362-a71f-fec03308dbe4	2025-10-30 12:24:24.888762	2025-10-30 12:24:24.888762
a62a9eb0-e9f7-408d-89bf-a003eab5e871	Debug Customer	debug@test.com	555-7777	\N	\N	\N	0.00	1c3e8b69-4796-4362-a71f-fec03308dbe4	2025-10-30 12:26:39.998262	2025-10-30 12:26:39.998262
7e2bcef8-6b89-4f64-8a18-4e6a659c6375	Audit Debug Customer	auditdebug@test.com	555-9999	\N	\N	\N	0.00	1c3e8b69-4796-4362-a71f-fec03308dbe4	2025-10-30 12:27:14.291498	2025-10-30 12:27:14.291498
1a46b604-da1a-4f10-b312-6ca38b4c26a4	muhsin	\N	+905397444722	Esenler mah. Adnan Menderes cad.\nGülevler sitesi No:9 Daire:11	\N	\N	0.00	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-30 12:05:40.583582	2025-10-30 12:05:40.583582
\.


--
-- Data for Name: email_outbox; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.email_outbox (id, "to", subject, provider, success, "messageId", "correlationId", "userId", "tenantId", "tokenId", type, "createdAt") FROM stdin;
bfc4f476-b1de-4a14-ac1a-9928bea28e53	basol28@gmail.com	E-posta Doğrulama	log	t	\N	88a0a949-cb26-491f-aca7-139a3d456423	ebc179cf-e019-465c-a050-bf47e8b0ac3d	b73f26c7-494d-46f7-8f01-835dde396010	d19aaeed-85c4-405c-8a8f-b998b0169794	verify	2025-11-13 06:34:19.793846
18828fa3-9a59-4464-aab5-037876f00a13	test_reports_qa@example.com	E-posta Doğrulama	log	t	\N	00338f11-9873-40b6-8c29-30a0b36ec551	866e1974-3db7-46e9-bd98-17aafea08b14	7acc12f9-0d05-4290-9a2b-49f0cdc8cad8	3ab4bdec-1975-413b-8526-cf1c23af7d73	verify	2025-11-13 07:01:24.61759
bfb43868-0527-43c0-a6ac-e1e469a8ff7a	test_reports_qa2@example.com	E-posta Doğrulama	log	t	\N	4da799f4-2337-4db6-ad7f-a13e0b06cdb4	afe6f746-b1d7-4dd4-ac25-7321250886ea	7520e2ea-2f37-4b0b-8591-4a79c31b8af1	eae01271-28f7-4c7d-a3e0-fc5772812e2b	verify	2025-11-13 07:02:10.468869
4ca73ecd-b13a-4d52-9231-deed220b39d6	basol17@gmail.com	Invitation to join Veli Başol's Organization	log	t	\N	\N	\N	\N	\N	\N	2025-11-13 08:31:14.50714
c8e93a02-64fb-43be-9b4e-5a67da152ee7	ekgelir17@gmail.com	Invitation to join Veli Başol's Organization	log	t	\N	\N	\N	\N	\N	\N	2025-11-13 08:31:51.128718
0852ca92-168b-4932-8310-59e52b8b3877	basol17@gmail.com	Reminder: Invitation to join Veli Başol's Organization	log	t	\N	\N	\N	\N	\N	\N	2025-11-13 08:32:54.065668
c87ce444-eb69-4e2c-84c0-4dd52c4b88f2	basol17@gmail.com	Reminder: Invitation to join Veli Başol's Organization	log	t	\N	\N	\N	\N	\N	\N	2025-11-13 09:01:55.449111
fb470c7a-2f7e-4a55-a3f2-40438d70675b	basol17@gmail.com	Reminder: Invitation to join Veli Başol's Organization	ses	t	\N	\N	\N	\N	\N	\N	2025-11-13 09:37:45.387544
48e44d42-2422-480d-8d3d-2687795f6d22	basol17@gmail.com	Reminder: Invitation to join Veli Başol's Organization	ses	t	\N	\N	\N	\N	\N	\N	2025-11-13 09:39:52.988019
47f98fa5-a31b-4194-9707-b3e56aa0cdd2	basol17@gmail.com	Reminder: Invitation to join Veli Başol's Organization	ses	t	0107019a7ca5df0c-ec4b2118-b7c5-4640-8240-d5492afdeb6e-000000	\N	\N	\N	\N	\N	2025-11-13 09:57:16.537788
\.


--
-- Data for Name: email_suppression; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.email_suppression (id, email, reason, "createdAt") FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.email_verification_tokens (id, "userId", "tokenHash", "expiresAt", "usedAt", "createdAt", ip, ua) FROM stdin;
d19aaeed-85c4-405c-8a8f-b998b0169794	ebc179cf-e019-465c-a050-bf47e8b0ac3d	9e75e9dae38baa97df9e8e86e911ff0c7d0f51152e915d796777a54b3b274ba2	2025-11-14 06:34:19.787	\N	2025-11-13 06:34:19.788036	\N	\N
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.expenses (id, "expenseNumber", "tenantId", "supplierId", description, "expenseDate", amount, category, status, notes, "receiptUrl", "createdAt", "updatedAt", is_voided, void_reason, voided_at, voided_by) FROM stdin;
66b96bf6-ae85-4e35-b8a7-f7b4834c785f	EXP-2025-001	26b93df7-9d6f-4d26-b082-f2d806096c9c	74ccef5d-e272-44c5-bbab-015a2cf90f62	Ofis Malzemeleri	2025-10-05	1500.00	supplies	paid	Kırtasiye alımı	\N	2025-10-27 09:13:24.664504	2025-10-27 09:13:24.664504	f	\N	\N	\N
449e8d6b-c079-4c6a-bfd7-692b8be19539	EXP-2025-002	26b93df7-9d6f-4d26-b082-f2d806096c9c	74ccef5d-e272-44c5-bbab-015a2cf90f62	Elektrik Faturası	2025-10-10	800.00	utilities	approved	Ekim ayı elektrik	\N	2025-10-27 09:13:24.664504	2025-10-27 09:13:24.664504	f	\N	\N	\N
6c96173c-fca1-4c37-91a7-ec0d7663046e	EXP-2025-615999	e2dedaf4-2605-4614-8dda-d8745d19d214	\N	arnavutluk seyahati	2025-10-27	2000.00	travel	paid		\N	2025-10-27 12:53:35.999329	2025-10-27 12:53:35.999329	f	\N	\N	\N
edbe9fb7-0a4e-4f3f-b172-601cf8924da8	EXP-2025-750687	e2dedaf4-2605-4614-8dda-d8745d19d214	\N	sosyal medya	2025-10-27	2000.00	marketing	paid		\N	2025-10-27 12:55:50.687677	2025-10-27 12:55:50.687677	f	\N	\N	\N
734ba741-ce0e-4d5f-bd84-22c0e6c38c3a	EXP-2025-884493	e2dedaf4-2605-4614-8dda-d8745d19d214	\N	dükkan kirası	2025-10-27	5000.00	rent	paid		\N	2025-10-27 12:58:04.493897	2025-10-27 12:58:04.493897	f	\N	\N	\N
\.


--
-- Data for Name: fiscal_periods; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.fiscal_periods (id, "tenantId", name, "periodStart", "periodEnd", "isLocked", "lockedAt", "lockedBy", "lockReason", "createdAt", "updatedAt") FROM stdin;
1a621ee6-23ef-448a-aba1-32131e4caef9	e2dedaf4-2605-4614-8dda-d8745d19d214	ekim	2025-10-01	2025-10-31	f	\N	\N	\N	2025-10-30 17:31:16.618624	2025-11-01 13:45:44.507159
\.


--
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.invites (id, "organizationId", email, role, token, "expiresAt", "acceptedAt", "createdAt") FROM stdin;
f4f2e7aa-3926-47c5-831d-58d2acd1a22f	57d4feb5-d6b5-4ff0-b8ea-66aa81e9aae7	basol17@gmail.com	MEMBER	905b8f412174aac1f8bf653dd09d1691e745ba590def752bb6a64684c669466f	2025-11-07 22:49:18.305	\N	2025-10-31 22:43:22.517351
0a618994-a32f-455f-917b-78bcfb26bea8	16bb0656-4845-464e-97d4-147eb39a670b	basol17@gmail.com	MEMBER	24af5bfe9b0db77a3566cf33390460f001e636680aea21f903f0ed15ec2138e4	2025-11-20 09:57:16.321	\N	2025-11-13 08:31:14.496542
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.invoices (id, "invoiceNumber", "tenantId", "customerId", "issueDate", "dueDate", subtotal, "taxAmount", "discountAmount", total, status, notes, "saleId", type, "refundedInvoiceId", items, "createdAt", "updatedAt", is_voided, void_reason, voided_at, voided_by) FROM stdin;
6384d16b-0f3e-4be1-afef-4f4ef08f111f	INV-2025-001	26b93df7-9d6f-4d26-b082-f2d806096c9c	7dabfdde-8711-4c41-a062-db3bfdaf49c0	2025-10-01	2025-10-31	10000.00	1800.00	0.00	11800.00	paid	İlk demo fatura	\N	\N	\N	[{"total": 30000, "quantity": 2, "productId": "0caeb2ba-f255-4f0d-9e9f-b5bbaddb6c8f", "unitPrice": "15000.00", "productName": "Laptop"}]	2025-10-27 09:13:24.662013	2025-10-27 09:13:24.662013	f	\N	\N	\N
b1da9e7b-8099-4245-ab22-3bb7892059c8	INV-2025-002	26b93df7-9d6f-4d26-b082-f2d806096c9c	7dabfdde-8711-4c41-a062-db3bfdaf49c0	2025-10-15	2025-11-15	5000.00	900.00	200.00	5700.00	sent	İkinci demo fatura	\N	\N	\N	[{"total": 750, "quantity": 5, "productId": "be1c8946-27b1-4421-953a-4ffe577e3f9b", "unitPrice": "150.00", "productName": "Mouse"}]	2025-10-27 09:13:24.662013	2025-10-27 09:13:24.662013	f	\N	\N	\N
f5e92793-ee47-4c51-98e4-a303b8c9c159	INV-2025-10-006	e2dedaf4-2605-4614-8dda-d8745d19d214	100fe332-c9db-469a-8613-9dc982e86a40	2025-10-27	2025-11-26	10.00	1.00	0.00	11.00	paid		\N	product	\N	[{"total": 10, "taxRate": 10, "quantity": 1, "productId": "22146672-c8b5-486d-96b2-36df5110278f", "unitPrice": 10, "description": "ekmek", "productName": "ekmek"}]	2025-10-27 12:46:08.026475	2025-10-27 12:46:08.026475	f	\N	\N	\N
f8e9690b-ddfb-4a25-825d-2ddf22cc1753	INV-2025-10-008	e2dedaf4-2605-4614-8dda-d8745d19d214	100fe332-c9db-469a-8613-9dc982e86a40	2025-10-29	2025-11-28	300.00	30.00	0.00	330.00	sent	Bu fatura SAL-2025-10-001 numaralı satıştan oluşturulmuştur.	1761738362601	product	\N	[{"total": 300, "taxRate": 10, "quantity": 3, "productId": "b7f07883-d918-4392-b010-8d5417dce08f", "unitPrice": 100, "description": "pasta", "productName": "pasta"}]	2025-10-29 11:46:07.999451	2025-10-30 17:42:03.058816	f	\N	\N	\N
6a1f7999-7faf-48d4-acf2-5a72cfa0e48e	INV-2025-10-009	e2dedaf4-2605-4614-8dda-d8745d19d214	1a46b604-da1a-4f10-b312-6ca38b4c26a4	2025-10-30	2025-11-29	10.00	1.00	0.00	11.00	draft		\N	product	\N	[{"total": 10, "taxRate": 10, "quantity": 1, "productId": "22146672-c8b5-486d-96b2-36df5110278f", "unitPrice": 10, "description": "ekmek", "productName": "ekmek"}]	2025-10-30 14:51:55.139834	2025-10-30 14:51:55.139834	f	\N	\N	\N
bcbc1120-09e6-4ff2-9302-fcdaecab82c6	INV-2025-10-010	e2dedaf4-2605-4614-8dda-d8745d19d214	1a46b604-da1a-4f10-b312-6ca38b4c26a4	2025-10-30	2025-11-29	500.00	50.00	0.00	550.00	sent	Bu fatura SAL-2025-10-001 numaralı satıştan oluşturulmuştur.	1761851287837	product	\N	[{"total": 500, "taxRate": 10, "quantity": 5, "productId": "e1d9a9ed-39d1-4fa4-8bf8-4a371f396512", "unitPrice": 100, "description": "makarna", "productName": "makarna"}]	2025-10-30 19:08:12.273256	2025-10-30 19:08:12.273256	f	\N	\N	\N
8e777d5c-07d8-44f5-bcd7-6233929ab3a6	INV-2025-10-011	e2dedaf4-2605-4614-8dda-d8745d19d214	ab3007bb-41ab-4fac-ad15-78f2bee3a27d	2025-10-31	2025-11-30	50.00	5.00	0.00	55.00	paid		\N	product	\N	[{"total": 50, "taxRate": 10, "quantity": 5, "productId": "22146672-c8b5-486d-96b2-36df5110278f", "unitPrice": 10, "description": "ekmek", "productName": "ekmek"}]	2025-10-31 14:40:21.911513	2025-10-31 14:40:21.911513	f	\N	\N	\N
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
11	1729369200000	AddIndexes1729369200000
12	1729545000000	AddProductCategoriesAndTaxRateOverride1729545000000
13	1730282000000	CreateAuditLogTable1730282000000
14	1761775949182	AddGdprFieldsToUsers1761775949182
15	1730282400000	AddFiscalPeriodsAndSoftDelete1730282400000
16	1698854400000	AddMultiTenantSupport1698854400000
17	1730475000000	AddLegalComplianceFieldsToTenant1730475000000
18	1762000000000	AddEmailVerificationAndReset1762000000000
19	1762015200000	UniqueNormalizedCustomerEmailPerTenant1762015200000
20	1762100000000	CreateSalesTable1762100000000
21	1762100000001	AddUniqueIndexOnSalesSourceQuote1762100000001
22	1762100000002	AddSaleNumberToSales1762100000002
23	1762115200000	UniqueProductCodePerTenant1762115200000
24	1762115300000	UniqueSaleNumberPerTenant1762115300000
25	1762200000000	CreateQuotesTable1762200000000
26	1762200000001	QuotesUniquePerTenant1762200000001
27	1762300000000	AddNotificationPreferencesToUsers1762300000000
28	1762400000000	CreateAuthTokenTables1762400000000
29	1762500000000	CreateEmailSuppressionTable1762500000000
30	1762500000000	CreateEmailOutbox1762500000000
31	1762500000000	AddCancelAtPeriodEndToTenants1762500000000
32	1762759200000	AddStripeColumnsToTenants1762759200000
33	1762800000000	CreateBankAccountsTable1762800000000
34	1762800000001	SeedBankAccountsIfMissing1762800000001
\.


--
-- Data for Name: organization_members; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.organization_members (id, "organizationId", "userId", role, "createdAt") FROM stdin;
6c6360c7-77aa-4f65-b3f6-2ab027dbfa67	d88e638e-17c0-4a1a-819f-05fac4ec42a1	24f96336-536e-4353-b200-0ed6bdf1fae1	OWNER	2025-10-31 10:12:59.307228
6f145159-91e8-436f-832d-002b4bd5d311	aac7bf5b-5fc4-45aa-a362-20ffdbd42485	a8b99389-99cf-4d05-8b93-f8e46ad01b5b	OWNER	2025-10-31 10:12:59.307228
06069d83-1e30-49a1-8a74-e55a1f3cc4e7	8148312a-9702-4c4f-aa30-22f50f557379	aded27bd-7192-4f72-81f6-060858d2f89b	OWNER	2025-10-31 10:12:59.307228
8860b090-2639-4436-b636-c3ef7e335430	8cf5595b-4075-4d1b-8c4a-bd775c14c837	1a38a36b-f16e-4ead-8627-73c9ebcc9024	OWNER	2025-10-31 10:12:59.307228
a5bfec5f-9861-4200-9c8d-be33e4da4a45	99e1c172-cf00-45fd-b68d-f11e507aae1e	f66c54d8-5b5c-4b7f-b5ed-fc00251cf7e7	OWNER	2025-10-31 10:12:59.307228
8c40386a-cf13-45e1-94ac-c23e6fd8f4b9	9e350914-591b-4e03-85a2-9de5ffa66b22	e311dc6b-7123-40af-98e1-1c997b27e3bd	OWNER	2025-10-31 10:12:59.307228
09340813-4291-42aa-beae-686259e6218f	57d4feb5-d6b5-4ff0-b8ea-66aa81e9aae7	394e3bcc-9fe5-4e88-bd25-5e32d35a1169	OWNER	2025-10-31 10:12:59.307228
b005e676-6e22-4128-90b1-57f251108557	bbbaccae-a2ba-440c-a6c0-d13e00acf8f3	2e145c6e-6d49-4d11-bd56-8c361a9665ce	OWNER	2025-10-31 10:12:59.307228
74acd772-d1bb-4a96-b343-8f92e7d2a27b	16bb0656-4845-464e-97d4-147eb39a670b	ebc179cf-e019-465c-a050-bf47e8b0ac3d	OWNER	2025-11-13 07:48:59.086631
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.organizations (id, name, plan, "createdAt", "updatedAt") FROM stdin;
d88e638e-17c0-4a1a-819f-05fac4ec42a1	Ahmet Yılmaz's Organization	STARTER	2025-10-31 10:12:59.307228	2025-10-31 10:12:59.307228
aac7bf5b-5fc4-45aa-a362-20ffdbd42485	Ayşe Kaya's Organization	STARTER	2025-10-31 10:12:59.307228	2025-10-31 10:12:59.307228
8148312a-9702-4c4f-aa30-22f50f557379	Super Admin's Organization	STARTER	2025-10-31 10:12:59.307228	2025-10-31 10:12:59.307228
8cf5595b-4075-4d1b-8c4a-bd775c14c837	Admin User's Organization	STARTER	2025-10-31 10:12:59.307228	2025-10-31 10:12:59.307228
99e1c172-cf00-45fd-b68d-f11e507aae1e	Test Demo's Organization	STARTER	2025-10-31 10:12:59.307228	2025-10-31 10:12:59.307228
9e350914-591b-4e03-85a2-9de5ffa66b22	Test User's Organization	STARTER	2025-10-31 10:12:59.307228	2025-10-31 10:12:59.307228
bbbaccae-a2ba-440c-a6c0-d13e00acf8f3	Demo User's Organization	STARTER	2025-10-31 10:12:59.307228	2025-10-31 10:12:59.307228
57d4feb5-d6b5-4ff0-b8ea-66aa81e9aae7	User 's Organization	PRO	2025-10-31 10:12:59.307228	2025-10-31 14:42:32.94033
eb84543e-72e8-48cb-af5c-c6fd61194232	Mustafa Başol's Organization	STARTER	2025-10-31 22:55:50.954513	2025-10-31 22:55:50.954513
16bb0656-4845-464e-97d4-147eb39a670b	Veli Başol's Organization	STARTER	2025-11-13 07:48:59.080728	2025-11-13 07:48:59.080728
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.password_reset_tokens (id, "userId", "tokenHash", "expiresAt", "usedAt", "createdAt", ip, ua) FROM stdin;
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.product_categories (id, name, "taxRate", "isActive", "tenantId", "createdAt", "updatedAt", "parentId", "isProtected") FROM stdin;
809d540d-8005-4536-b23b-5bcfa9fc6c34	Elektronik	18.00	t	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.656087	2025-10-27 09:13:24.656087	\N	f
48f48d90-95d9-4f0b-8cf3-e76d9db3ff27	Gıda	8.00	t	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.656087	2025-10-27 09:13:24.656087	\N	f
bd9117d5-6c48-48c0-adfe-4471a8d902aa	Ürünler	18.00	t	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 11:30:31.272423	2025-10-27 11:30:31.272423	\N	t
b21668ef-0ec0-4eea-85ee-daf9de57baf9	Hizmetler	18.00	t	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 11:30:31.272423	2025-10-27 11:30:31.272423	\N	t
5fa873d3-6856-4c7a-8ef9-5a5ec61a199c	Tekstil	20.00	f	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 09:13:24.656087	2025-10-27 11:32:05.802302	\N	f
1472f5d1-781b-4d31-bea2-644b24243840	mobilya	5.00	f	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 09:40:30.667966	2025-10-27 11:32:07.699062	\N	f
5e3bc846-71d7-4ad3-b1a8-600bfa987401	elektronik	18.00	f	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 09:40:15.17161	2025-10-27 11:32:13.185405	\N	f
53cb74dd-ac59-49ad-b7d0-3b07c5272f31	Ürünler	18.00	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 11:49:19.509313	2025-10-27 11:49:19.509313	\N	t
19588a80-669b-432f-9540-d567831d619c	Hizmetler	10.00	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 11:49:19.509313	2025-10-27 11:51:54.312313	\N	t
835a3a20-5547-46ca-9835-9ff4555f98ed	Hizmetler	18.00	t	48ee2d2d-cad8-4518-a652-c1a5284efefd	2025-10-27 11:53:54.304132	2025-10-27 11:53:54.304132	\N	t
496d48fc-6f2f-4291-8840-07b44f181dfd	Ürünler	18.00	t	48ee2d2d-cad8-4518-a652-c1a5284efefd	2025-10-27 11:53:54.304132	2025-10-27 11:53:54.304132	\N	t
fc85d70f-f101-4f49-83b0-e8a64f41f3d4	gıda	10.00	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 12:31:13.507588	2025-10-27 12:31:13.507588	53cb74dd-ac59-49ad-b7d0-3b07c5272f31	f
4005cd98-7b3f-417a-b901-d8c7ec2ff34a	Elektronik	18.00	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 12:36:24.73558	2025-10-27 12:36:24.73558	53cb74dd-ac59-49ad-b7d0-3b07c5272f31	f
6c4d6cce-cd5b-4aff-9a54-302e372f2787	temsilcilik	20.00	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 12:37:08.115093	2025-10-27 12:37:08.115093	19588a80-669b-432f-9540-d567831d619c	f
62d11ac3-f88f-48be-982f-054e485ecca6	danışmanlık	20.01	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 12:40:32.618132	2025-10-27 12:40:32.618132	19588a80-669b-432f-9540-d567831d619c	f
25b53d13-612d-4166-914d-64f7ce9315ff	yemek servisi	18.00	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-28 21:49:16.000954	2025-10-28 21:49:16.000954	19588a80-669b-432f-9540-d567831d619c	f
9b35152a-7e2f-411e-9c64-64168e246e49	Hizmetler	18.00	t	90e89a71-a981-401b-8c7f-1b470cdc24dd	2025-10-29 23:12:54.570395	2025-10-29 23:12:54.570395	\N	t
0dbae53e-12b8-49c9-963b-eec2c82dce40	Ürünler	18.00	t	90e89a71-a981-401b-8c7f-1b470cdc24dd	2025-10-29 23:12:54.570395	2025-10-29 23:12:54.570395	\N	t
9b863f72-f5db-4ec5-9623-13ec0cefd470	Hizmetler	18.00	t	864bd5e5-8d5d-46a4-824a-c69c39703fc9	2025-10-30 10:11:04.902211	2025-10-30 10:11:04.902211	\N	t
a1c462f9-36ab-401f-8839-ff4786495572	Ürünler	18.00	t	864bd5e5-8d5d-46a4-824a-c69c39703fc9	2025-10-30 10:11:04.902211	2025-10-30 10:11:04.902211	\N	t
bcde7ee3-efaf-48af-bf28-55e5e46f8a82	Hizmetler	18.00	t	1c3e8b69-4796-4362-a71f-fec03308dbe4	2025-10-30 12:22:29.751916	2025-10-30 12:22:29.751916	\N	t
568555a6-2c50-447c-b8b3-9252bf4d255b	Ürünler	18.00	t	1c3e8b69-4796-4362-a71f-fec03308dbe4	2025-10-30 12:22:29.751916	2025-10-30 12:22:29.751916	\N	t
3e0e404f-6032-4cd8-b765-9c10757fbeab	Hizmetler	18.00	t	26d00eab-d879-48cc-ad09-fb60d63f3696	2025-10-31 22:55:42.883443	2025-10-31 22:55:42.883443	\N	t
bd13d177-b267-4322-bdf7-36ddac7ed7e4	Ürünler	18.00	t	26d00eab-d879-48cc-ad09-fb60d63f3696	2025-10-31 22:55:42.883443	2025-10-31 22:55:42.883443	\N	t
770a0abe-2db9-4be9-ad8f-5ff7ef0c0018	Hizmetler	18.00	t	b73f26c7-494d-46f7-8f01-835dde396010	2025-11-13 06:34:19.53484	2025-11-13 06:34:19.53484	\N	t
2c74cb2d-3349-4966-b3e2-4dbbb64188bf	Ürünler	18.00	t	b73f26c7-494d-46f7-8f01-835dde396010	2025-11-13 06:34:19.53484	2025-11-13 06:34:19.53484	\N	t
2df83f8b-30ff-45e6-8ddc-441451c84026	Hizmetler	18.00	t	7acc12f9-0d05-4290-9a2b-49f0cdc8cad8	2025-11-13 07:01:24.356612	2025-11-13 07:01:24.356612	\N	t
53f8e198-9629-4204-bacc-4146a27303e1	Ürünler	18.00	t	7acc12f9-0d05-4290-9a2b-49f0cdc8cad8	2025-11-13 07:01:24.356612	2025-11-13 07:01:24.356612	\N	t
dd97cd13-3841-4fd5-87df-c7ff73ced75e	Hizmetler	18.00	t	7520e2ea-2f37-4b0b-8591-4a79c31b8af1	2025-11-13 07:02:10.210767	2025-11-13 07:02:10.210767	\N	t
391ed5f7-1879-4f83-ac8a-83c3600571ec	Ürünler	18.00	t	7520e2ea-2f37-4b0b-8591-4a79c31b8af1	2025-11-13 07:02:10.210767	2025-11-13 07:02:10.210767	\N	t
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.products (id, name, code, description, price, cost, stock, "minStock", unit, category, barcode, "taxRate", "categoryTaxRateOverride", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
0caeb2ba-f255-4f0d-9e9f-b5bbaddb6c8f	Laptop	LPT-001	Dell Laptop 15"	15000.00	12000.00	10.00	2.00	adet	Elektronik	\N	18.00	\N	t	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.657717	2025-10-27 09:13:24.657717
be1c8946-27b1-4421-953a-4ffe577e3f9b	Mouse	MOU-001	Kablosuz Mouse	150.00	100.00	50.00	10.00	adet	Elektronik	\N	18.00	\N	t	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.657717	2025-10-27 09:13:24.657717
b7f07883-d918-4392-b010-8d5417dce08f	pasta	1451	\N	100.00	0.00	7.00	10.00	adet	gıda	\N	10.00	20.00	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 12:47:37.624751	2025-10-29 11:46:03.417504
e1d9a9ed-39d1-4fa4-8bf8-4a371f396512	makarna	1451s	\N	100.00	0.00	994.00	10.00	adet	gıda	\N	10.00	\N	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-30 12:01:14.116706	2025-10-30 19:08:07.146382
22146672-c8b5-486d-96b2-36df5110278f	ekmek	145	\N	10.00	0.00	94.00	10.00	adet	gıda	\N	10.00	\N	t	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 12:45:51.429809	2025-10-31 14:40:22.370766
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.quotes (id, "publicId", "quoteNumber", "tenantId", "customerId", "customerName", "issueDate", "validUntil", currency, total, status, items, "scopeOfWorkHtml", version, revisions, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.sales (id, "tenantId", "customerId", "saleDate", subtotal, "taxAmount", "discountAmount", total, status, "sourceQuoteId", "invoiceId", items, notes, "createdAt", "updatedAt", "saleNumber") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.suppliers (id, name, email, phone, address, "taxNumber", company, balance, "tenantId", "createdAt", "updatedAt") FROM stdin;
74ccef5d-e272-44c5-bbab-015a2cf90f62	Tedarik A.Ş.	tedarik@example.com	+90 555 444 5566	İstanbul	4444444444	Tedarik A.Ş.	-2000.00	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.653822	2025-10-27 09:13:24.653822
82f7e1ec-3d5d-43c1-a5de-44863424bb1d	Malzeme Ltd.	malzeme@example.com	+90 555 555 6677	Bursa	5555555555	Malzeme Ltd.	-1500.00	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 09:13:24.653822	2025-10-27 09:13:24.653822
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.tenants (id, name, slug, "companyName", "taxNumber", address, phone, email, "subscriptionPlan", status, "subscriptionExpiresAt", "maxUsers", settings, features, "createdAt", "updatedAt", website, "taxOffice", "mersisNumber", "kepAddress", "siretNumber", "sirenNumber", "apeCode", "tvaNumber", "rcsNumber", steuernummer, "umsatzsteuerID", handelsregisternummer, finanzamt, "einNumber", "taxIDNumber", "businessLicense", "salesTaxNumber", "cancelAtPeriodEnd", "stripeCustomerId", "stripeSubscriptionId", "billingInterval", geschaeftsfuehrer, "taxId", "businessLicenseNumber", "stateOfIncorporation") FROM stdin;
26b93df7-9d6f-4d26-b082-f2d806096c9c	Demo Şirket 1	demo-sirket-1	Demo Ticaret A.Ş.	1234567890	İstanbul, Türkiye	+90 555 111 2233	demo1@test.com	professional	active	\N	5	\N	\N	2025-10-27 09:13:24.570952	2025-10-27 09:13:24.570952	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
e2dedaf4-2605-4614-8dda-d8745d19d214	Demo Şirket 2	demo-sirket-2	Örnek Danışmanlık Ltd.	9876543210	Ankara, Türkiye	+90 555 444 5566	demo2@test.com	basic	active	\N	5	\N	\N	2025-10-27 09:13:24.575818	2025-10-27 09:13:24.575818	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
48ee2d2d-cad8-4518-a652-c1a5284efefd	Test Organizasyon	test-organizasyon	Test Muhasebe Ltd.	5555555555	İzmir, Türkiye	+90 555 777 8899	test@test.com	enterprise	active	\N	5	\N	\N	2025-10-27 09:13:24.579168	2025-10-27 09:13:24.579168	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
90e89a71-a981-401b-8c7f-1b470cdc24dd	Test User	test-user	\N	\N	\N	\N	\N	free	trial	2025-11-12 23:12:54.559	5	{}	{"apiAccess": false, "multiUser": true, "exportData": false, "basicReporting": true, "advancedReporting": false, "customerManagement": true}	2025-10-29 23:12:54.5622	2025-10-29 23:12:54.5622	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
864bd5e5-8d5d-46a4-824a-c69c39703fc9	Demo User	demo-user	\N	\N	\N	\N	\N	free	trial	2025-11-13 10:11:04.887	5	{}	{"apiAccess": false, "multiUser": true, "exportData": false, "basicReporting": true, "advancedReporting": false, "customerManagement": true}	2025-10-30 10:11:04.890033	2025-10-30 10:11:04.890033	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
1c3e8b69-4796-4362-a71f-fec03308dbe4	Test Demo	test-demo	\N	\N	\N	\N	\N	free	trial	2025-11-13 12:22:29.736	5	{}	{"apiAccess": false, "multiUser": true, "exportData": false, "basicReporting": true, "advancedReporting": false, "customerManagement": true}	2025-10-30 12:22:29.739614	2025-10-30 12:22:29.739614	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
02049c38-8a12-4ccd-8e44-a9d798a191ae	System	system	System Operations	\N	\N	\N	\N	enterprise	active	\N	5	\N	\N	2025-10-30 18:40:00.737702	2025-10-30 18:40:00.737702	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
26d00eab-d879-48cc-ad09-fb60d63f3696	Mustafa Başol	mustafa-ba-ol	\N	\N	\N	\N	\N	free	trial	2025-11-14 22:55:42.872	5	{}	{"apiAccess": false, "multiUser": true, "exportData": false, "basicReporting": true, "advancedReporting": false, "customerManagement": true}	2025-10-31 22:55:42.875261	2025-10-31 22:55:42.875261	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
7acc12f9-0d05-4290-9a2b-49f0cdc8cad8	QA Co	qa-co	QA Co	\N	\N	\N	\N	free	trial	2025-11-27 07:01:24.343	1	{}	{"apiAccess": false, "multiUser": true, "exportData": false, "basicReporting": true, "advancedReporting": false, "customerManagement": true}	2025-11-13 07:01:24.34743	2025-11-13 07:01:24.34743	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
7520e2ea-2f37-4b0b-8591-4a79c31b8af1	QA Co 1	qa-co-1	QA Co	\N	\N	\N	\N	free	trial	2025-11-27 07:02:10.206	1	{}	{"apiAccess": false, "multiUser": true, "exportData": false, "basicReporting": true, "advancedReporting": false, "customerManagement": true}	2025-11-13 07:02:10.20684	2025-11-13 07:02:10.20684	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
b73f26c7-494d-46f7-8f01-835dde396010	Veli Başol	veli-ba-ol	\N	\N	\N	\N	basol28@gmail.com	professional	active	2025-12-13 07:48:23	3	{}	{"apiAccess": false, "multiUser": true, "exportData": false, "basicReporting": true, "advancedReporting": false, "customerManagement": true}	2025-11-13 06:34:19.520568	2025-11-13 07:48:45.535086	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	cus_TPklg6zkbrLxCe	sub_1SSvGVK8pwobn5mA6UYPXbOr	month	\N	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: moneyflow
--

COPY public.users (id, email, password, "firstName", "lastName", role, "isActive", "lastLoginAt", "tenantId", "createdAt", "updatedAt", "deletionRequestedAt", "isPendingDeletion", "currentOrgId", twofactorsecret, twofactorenabled, backupcodes, twofactorenabledat, "twoFactorSecret", "isTwoFactorEnabled", "twoFactorBackupCodes", "twoFactorEnabled", "twoFactorEnabledAt", "isEmailVerified", "emailVerificationToken", "emailVerificationSentAt", "emailVerifiedAt", "passwordResetToken", "passwordResetExpiresAt", "notificationPreferences") FROM stdin;
ebc179cf-e019-465c-a050-bf47e8b0ac3d	basol28@gmail.com	$2b$12$wMad5h/qVciv0bVvZriVOu6HSJl.EAdh7F5CYsfb.Tq3v3wV/1jmm	Veli	Başol	tenant_admin	t	2025-11-13 09:57:12.307	b73f26c7-494d-46f7-8f01-835dde396010	2025-11-13 06:34:19.78374	2025-11-13 09:57:12.310261	\N	f	\N	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	{"expenseAlerts": true, "lowStockAlerts": true, "quoteReminders": true, "invoiceReminders": true, "salesNotifications": true}
1a38a36b-f16e-4ead-8627-73c9ebcc9024	admin@test.com	$2b$10$PeVvoOIEhn72yFxwoeqP9O3CfC9b6Toe8KfWUkwG3.SoMxuZpmaDq	Admin	User	tenant_admin	t	2025-10-31 22:52:14.458	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.643081	2025-10-31 22:52:14.459711	\N	f	8cf5595b-4075-4d1b-8c4a-bd775c14c837	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N
394e3bcc-9fe5-4e88-bd25-5e32d35a1169	user2@test.com	$2b$10$PeVvoOIEhn72yFxwoeqP9O3CfC9b6Toe8KfWUkwG3.SoMxuZpmaDq	User		user	t	2025-11-01 15:50:31.432	e2dedaf4-2605-4614-8dda-d8745d19d214	2025-10-27 09:13:24.646822	2025-11-01 15:50:31.43515	\N	f	57d4feb5-d6b5-4ff0-b8ea-66aa81e9aae7	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N
24f96336-536e-4353-b200-0ed6bdf1fae1	accountant1@test.com	$2b$10$PeVvoOIEhn72yFxwoeqP9O3CfC9b6Toe8KfWUkwG3.SoMxuZpmaDq	Ahmet	Yılmaz	accountant	t	\N	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.645553	2025-10-27 09:13:24.645553	\N	f	d88e638e-17c0-4a1a-819f-05fac4ec42a1	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N
a8b99389-99cf-4d05-8b93-f8e46ad01b5b	user3@test.com	$2b$10$PeVvoOIEhn72yFxwoeqP9O3CfC9b6Toe8KfWUkwG3.SoMxuZpmaDq	Ayşe	Kaya	accountant	t	\N	48ee2d2d-cad8-4518-a652-c1a5284efefd	2025-10-27 09:13:24.648245	2025-10-27 09:13:24.648245	\N	f	aac7bf5b-5fc4-45aa-a362-20ffdbd42485	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N
aded27bd-7192-4f72-81f6-060858d2f89b	superadmin@test.com	$2b$10$PeVvoOIEhn72yFxwoeqP9O3CfC9b6Toe8KfWUkwG3.SoMxuZpmaDq	Super	Admin	super_admin	t	\N	26b93df7-9d6f-4d26-b082-f2d806096c9c	2025-10-27 09:13:24.649523	2025-10-27 09:13:24.649523	\N	f	8148312a-9702-4c4f-aa30-22f50f557379	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N
f66c54d8-5b5c-4b7f-b5ed-fc00251cf7e7	testdemo@example.com	$2b$10$xzgxqogWFg7r/Pohgw4KyutBf37r.uUqbWO/fKhLmXbYRQ561shXa	Test	Demo	tenant_admin	t	2025-10-30 12:27:14.2	1c3e8b69-4796-4362-a71f-fec03308dbe4	2025-10-30 12:22:29.816372	2025-10-30 12:27:14.202131	\N	f	99e1c172-cf00-45fd-b68d-f11e507aae1e	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N
e311dc6b-7123-40af-98e1-1c997b27e3bd	test@example.com	$2b$10$Rg9Ztjrx2g9oYkOxMDpdEuS2caqzbJzk.CqJfBtBOJx2kw8HxseHu	Test	User	tenant_admin	f	2025-10-29 23:13:37.178	90e89a71-a981-401b-8c7f-1b470cdc24dd	2025-10-29 23:12:54.636332	2025-10-29 23:13:37.195	2025-10-29 23:13:37.195	t	9e350914-591b-4e03-85a2-9de5ffa66b22	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N
2e145c6e-6d49-4d11-bd56-8c361a9665ce	demo@test.com	$2b$10$QjHJlWYwT9yWzHdY6HmMo.m/yY45iYghuykc9RiEu/CKvtNP9z8ju	Demo	User	tenant_admin	t	2025-10-30 10:42:23.588	864bd5e5-8d5d-46a4-824a-c69c39703fc9	2025-10-30 10:11:04.971236	2025-10-30 10:42:23.589957	\N	f	bbbaccae-a2ba-440c-a6c0-d13e00acf8f3	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: moneyflow
--

SELECT pg_catalog.setval('public.migrations_id_seq', 34, true);


--
-- Name: audit_log PK_07fefa57f7f5ab8fc3f52b3ed0b; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT "PK_07fefa57f7f5ab8fc3f52b3ed0b" PRIMARY KEY (id);


--
-- Name: products PK_0806c755e0aca124e67c0cf6d7d; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "PK_0806c755e0aca124e67c0cf6d7d" PRIMARY KEY (id);


--
-- Name: customers PK_133ec679a801fab5e070f73d3ea; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "PK_133ec679a801fab5e070f73d3ea" PRIMARY KEY (id);


--
-- Name: sales PK_4f0bc990ae81dba46da680895ea; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "PK_4f0bc990ae81dba46da680895ea" PRIMARY KEY (id);


--
-- Name: tenants PK_53be67a04681c66b87ee27c9321; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "PK_53be67a04681c66b87ee27c9321" PRIMARY KEY (id);


--
-- Name: invoices PK_668cef7c22a427fd822cc1be3ce; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "PK_668cef7c22a427fd822cc1be3ce" PRIMARY KEY (id);


--
-- Name: product_categories PK_7069dac60d88408eca56fdc9e0c; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT "PK_7069dac60d88408eca56fdc9e0c" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: expenses PK_94c3ceb17e3140abc9282c20610; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "PK_94c3ceb17e3140abc9282c20610" PRIMARY KEY (id);


--
-- Name: quotes PK_99a0e8bcbcd8719d3a41f23c263; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT "PK_99a0e8bcbcd8719d3a41f23c263" PRIMARY KEY (id);


--
-- Name: fiscal_periods PK_9bb1e4e84a0d820b943e116888d; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT "PK_9bb1e4e84a0d820b943e116888d" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: suppliers PK_b70ac51766a9e3144f778cfe81e; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT "PK_b70ac51766a9e3144f778cfe81e" PRIMARY KEY (id);


--
-- Name: bank_accounts PK_c872de764f2038224a013ff25ed; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT "PK_c872de764f2038224a013ff25ed" PRIMARY KEY (id);


--
-- Name: tenants UQ_2310ecc5cb8be427097154b18fc; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "UQ_2310ecc5cb8be427097154b18fc" UNIQUE (slug);


--
-- Name: tenants UQ_32731f181236a46182a38c992a8; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "UQ_32731f181236a46182a38c992a8" UNIQUE (name);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: organization_members UQ_organization_members_org_user; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT "UQ_organization_members_org_user" UNIQUE ("organizationId", "userId");


--
-- Name: products UQ_products_tenantId_code; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "UQ_products_tenantId_code" UNIQUE ("tenantId", code);


--
-- Name: sales UQ_sales_tenant_saleNumber; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "UQ_sales_tenant_saleNumber" UNIQUE ("tenantId", "saleNumber");


--
-- Name: email_outbox email_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.email_outbox
    ADD CONSTRAINT email_outbox_pkey PRIMARY KEY (id);


--
-- Name: email_suppression email_suppression_email_key; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.email_suppression
    ADD CONSTRAINT email_suppression_email_key UNIQUE (email);


--
-- Name: email_suppression email_suppression_pkey; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.email_suppression
    ADD CONSTRAINT email_suppression_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: invites invites_pkey; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (id);


--
-- Name: invites invites_token_key; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_token_key UNIQUE (token);


--
-- Name: organization_members organization_members_pkey; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: IDX_audit_log_created_at; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_audit_log_created_at" ON public.audit_log USING btree ("createdAt");


--
-- Name: IDX_audit_log_entity; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_audit_log_entity" ON public.audit_log USING btree (entity);


--
-- Name: IDX_audit_log_entity_composite; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_audit_log_entity_composite" ON public.audit_log USING btree (entity, "entityId");


--
-- Name: IDX_audit_log_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_audit_log_tenant_id" ON public.audit_log USING btree ("tenantId");


--
-- Name: IDX_audit_log_user_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_audit_log_user_id" ON public.audit_log USING btree ("userId");


--
-- Name: IDX_bank_accounts_created_at; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_bank_accounts_created_at" ON public.bank_accounts USING btree ("createdAt");


--
-- Name: IDX_bank_accounts_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_bank_accounts_tenant_id" ON public.bank_accounts USING btree ("tenantId");


--
-- Name: IDX_customers_email; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_customers_email" ON public.customers USING btree (email);


--
-- Name: IDX_customers_tenant_created; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_customers_tenant_created" ON public.customers USING btree ("tenantId", "createdAt");


--
-- Name: IDX_customers_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_customers_tenant_id" ON public.customers USING btree ("tenantId");


--
-- Name: IDX_expenses_category; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_expenses_category" ON public.expenses USING btree (category);


--
-- Name: IDX_expenses_date; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_expenses_date" ON public.expenses USING btree ("expenseDate");


--
-- Name: IDX_expenses_is_voided; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_expenses_is_voided" ON public.expenses USING btree (is_voided);


--
-- Name: IDX_expenses_status; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_expenses_status" ON public.expenses USING btree (status);


--
-- Name: IDX_expenses_supplier_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_expenses_supplier_id" ON public.expenses USING btree ("supplierId");


--
-- Name: IDX_expenses_tenant_category; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_expenses_tenant_category" ON public.expenses USING btree ("tenantId", category);


--
-- Name: IDX_expenses_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_expenses_tenant_id" ON public.expenses USING btree ("tenantId");


--
-- Name: IDX_fiscal_periods_period_dates; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_fiscal_periods_period_dates" ON public.fiscal_periods USING btree ("tenantId", "periodStart", "periodEnd");


--
-- Name: IDX_fiscal_periods_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_fiscal_periods_tenant_id" ON public.fiscal_periods USING btree ("tenantId");


--
-- Name: IDX_invites_token; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_invites_token" ON public.invites USING btree (token);


--
-- Name: IDX_invoices_customer_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_invoices_customer_id" ON public.invoices USING btree ("customerId");


--
-- Name: IDX_invoices_due_date; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_invoices_due_date" ON public.invoices USING btree ("dueDate");


--
-- Name: IDX_invoices_is_voided; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_invoices_is_voided" ON public.invoices USING btree (is_voided);


--
-- Name: IDX_invoices_issue_date; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_invoices_issue_date" ON public.invoices USING btree ("issueDate");


--
-- Name: IDX_invoices_status; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_invoices_status" ON public.invoices USING btree (status);


--
-- Name: IDX_invoices_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_invoices_tenant_id" ON public.invoices USING btree ("tenantId");


--
-- Name: IDX_invoices_tenant_status; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_invoices_tenant_status" ON public.invoices USING btree ("tenantId", status);


--
-- Name: IDX_organization_members_organizationId; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_organization_members_organizationId" ON public.organization_members USING btree ("organizationId");


--
-- Name: IDX_organization_members_userId; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_organization_members_userId" ON public.organization_members USING btree ("userId");


--
-- Name: IDX_product_categories_tenantId; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_product_categories_tenantId" ON public.product_categories USING btree ("tenantId");


--
-- Name: IDX_product_categories_tenant_name; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE UNIQUE INDEX "IDX_product_categories_tenant_name" ON public.product_categories USING btree ("tenantId", name);


--
-- Name: IDX_products_category; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_products_category" ON public.products USING btree (category);


--
-- Name: IDX_products_code; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_products_code" ON public.products USING btree (code);


--
-- Name: IDX_products_tenant_category; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_products_tenant_category" ON public.products USING btree ("tenantId", category);


--
-- Name: IDX_products_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_products_tenant_id" ON public.products USING btree ("tenantId");


--
-- Name: IDX_quotes_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_quotes_tenant_id" ON public.quotes USING btree ("tenantId");


--
-- Name: IDX_sales_created_at; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_sales_created_at" ON public.sales USING btree ("createdAt");


--
-- Name: IDX_sales_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_sales_tenant_id" ON public.sales USING btree ("tenantId");


--
-- Name: IDX_suppliers_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_suppliers_tenant_id" ON public.suppliers USING btree ("tenantId");


--
-- Name: IDX_users_email; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_users_email" ON public.users USING btree (email);


--
-- Name: IDX_users_tenant_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX "IDX_users_tenant_id" ON public.users USING btree ("tenantId");


--
-- Name: UQ_customers_tenant_email_norm; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE UNIQUE INDEX "UQ_customers_tenant_email_norm" ON public.customers USING btree ("tenantId", lower(TRIM(BOTH FROM email))) WHERE (email IS NOT NULL);


--
-- Name: UQ_quotes_publicId; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE UNIQUE INDEX "UQ_quotes_publicId" ON public.quotes USING btree ("publicId");


--
-- Name: UQ_quotes_tenant_quoteNumber; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE UNIQUE INDEX "UQ_quotes_tenant_quoteNumber" ON public.quotes USING btree ("tenantId", "quoteNumber");


--
-- Name: UQ_sales_saleNumber; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE UNIQUE INDEX "UQ_sales_saleNumber" ON public.sales USING btree ("saleNumber");


--
-- Name: UQ_sales_tenant_quote; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE UNIQUE INDEX "UQ_sales_tenant_quote" ON public.sales USING btree ("tenantId", "sourceQuoteId") WHERE ("sourceQuoteId" IS NOT NULL);


--
-- Name: idx_email_outbox_created_at; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_email_outbox_created_at ON public.email_outbox USING btree ("createdAt");


--
-- Name: idx_email_outbox_to; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_email_outbox_to ON public.email_outbox USING btree ("to");


--
-- Name: idx_email_outbox_type; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_email_outbox_type ON public.email_outbox USING btree (type);


--
-- Name: idx_email_suppression_email; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE UNIQUE INDEX idx_email_suppression_email ON public.email_suppression USING btree (email);


--
-- Name: idx_evt_expires_at; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_evt_expires_at ON public.email_verification_tokens USING btree ("expiresAt");


--
-- Name: idx_evt_user_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_evt_user_id ON public.email_verification_tokens USING btree ("userId");


--
-- Name: idx_expenses_is_voided; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_expenses_is_voided ON public.expenses USING btree (is_voided);


--
-- Name: idx_invoices_is_voided; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_invoices_is_voided ON public.invoices USING btree (is_voided);


--
-- Name: idx_prt_expires_at; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_prt_expires_at ON public.password_reset_tokens USING btree ("expiresAt");


--
-- Name: idx_prt_user_id; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_prt_user_id ON public.password_reset_tokens USING btree ("userId");


--
-- Name: idx_users_emailverificationtoken; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_users_emailverificationtoken ON public.users USING btree ("emailVerificationToken");


--
-- Name: idx_users_passwordresettoken; Type: INDEX; Schema: public; Owner: moneyflow
--

CREATE INDEX idx_users_passwordresettoken ON public.users USING btree ("passwordResetToken");


--
-- Name: fiscal_periods FK_030a71ef0a0292a218408aed44c; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT "FK_030a71ef0a0292a218408aed44c" FOREIGN KEY ("lockedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoices FK_1df049f8943c6be0c1115541efb; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "FK_1df049f8943c6be0c1115541efb" FOREIGN KEY ("customerId") REFERENCES public.customers(id);


--
-- Name: audit_log FK_2621409ebc295c5da7ff3e41396; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT "FK_2621409ebc295c5da7ff3e41396" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sales FK_37606c7b1560c6be428c7a48959; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "FK_37606c7b1560c6be428c7a48959" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: customers FK_37c1a605468d156e6a8f78f1dc5; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "FK_37c1a605468d156e6a8f78f1dc5" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: sales FK_3a92cf6add00043cef9833db1cd; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "FK_3a92cf6add00043cef9833db1cd" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: audit_log FK_4167b21288ab6e16239cb1d5016; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT "FK_4167b21288ab6e16239cb1d5016" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: product_categories FK_511a82b0123c941ba3f49ab025e; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT "FK_511a82b0123c941ba3f49ab025e" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: bank_accounts FK_56cb500b41e924b1fadc5051d5d; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT "FK_56cb500b41e924b1fadc5051d5d" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: quotes FK_6035d30fc2417ed19972a7ce028; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT "FK_6035d30fc2417ed19972a7ce028" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: expenses FK_6103e35625584836bed4dab6b92; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "FK_6103e35625584836bed4dab6b92" FOREIGN KEY (voided_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: products FK_6804855ba1a19523ea57e0769b4; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_6804855ba1a19523ea57e0769b4" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: invoices FK_7665522bed89854413b7d6cfe71; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "FK_7665522bed89854413b7d6cfe71" FOREIGN KEY ("refundedInvoiceId") REFERENCES public.invoices(id);


--
-- Name: invoices FK_89c82485e364081f457b210120d; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "FK_89c82485e364081f457b210120d" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id);


--
-- Name: fiscal_periods FK_a2c50d3c70519722b5b74febd60; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT "FK_a2c50d3c70519722b5b74febd60" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users FK_c58f7e88c286e5e3478960a998b; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "FK_c58f7e88c286e5e3478960a998b" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: expenses FK_cb04770a68c157a22fa42cc0506; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "FK_cb04770a68c157a22fa42cc0506" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id);


--
-- Name: quotes FK_ccf1feb9e280240bb05dc0aed2a; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT "FK_ccf1feb9e280240bb05dc0aed2a" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: suppliers FK_dd5cd678c4e94ddb93a224e7116; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT "FK_dd5cd678c4e94ddb93a224e7116" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: invoices FK_e9682eb7c1839bb55c6b77e5b81; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "FK_e9682eb7c1839bb55c6b77e5b81" FOREIGN KEY (voided_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: expenses FK_f754faa125acaf008866b6635bc; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "FK_f754faa125acaf008866b6635bc" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id);


--
-- Name: fiscal_periods FK_fiscal_periods_locked_by; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT "FK_fiscal_periods_locked_by" FOREIGN KEY ("lockedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: fiscal_periods FK_fiscal_periods_tenant; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT "FK_fiscal_periods_tenant" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: invites FK_invites_organizationId; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT "FK_invites_organizationId" FOREIGN KEY ("organizationId") REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_members FK_organization_members_organizationId; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT "FK_organization_members_organizationId" FOREIGN KEY ("organizationId") REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_members FK_organization_members_userId; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT "FK_organization_members_userId" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens fk_evt_user; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT fk_evt_user FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens fk_prt_user; Type: FK CONSTRAINT; Schema: public; Owner: moneyflow
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT fk_prt_user FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict A1GWb3khMnmHLHh2y9x88jAOiw66DwyU2cwJCdmD5QaU4ZJVur2gtIW9fGicSIK

