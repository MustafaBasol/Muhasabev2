-- Create required extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enums if not exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'role_enum') THEN
    CREATE TYPE role_enum AS ENUM ('OWNER', 'ADMIN', 'MEMBER');
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'plan_enum') THEN
    CREATE TYPE plan_enum AS ENUM ('STARTER', 'PRO', 'BUSINESS');
  END IF;
END$$;

-- Create organizations table
CREATE TABLE IF NOT EXISTS organizations (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name varchar NOT NULL,
  plan plan_enum NOT NULL DEFAULT 'STARTER',
  "createdAt" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create organization_members table
CREATE TABLE IF NOT EXISTS organization_members (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  "organizationId" uuid NOT NULL,
  "userId" uuid NOT NULL,
  role role_enum NOT NULL DEFAULT 'MEMBER',
  "createdAt" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FK_organization_members_organizationId"
    FOREIGN KEY ("organizationId") REFERENCES organizations(id) ON DELETE CASCADE,
  CONSTRAINT "FK_organization_members_userId"
    FOREIGN KEY ("userId") REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT "UQ_organization_members_org_user" UNIQUE("organizationId", "userId")
);

-- Indexes for organization_members
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_organization_members_userid') THEN
    CREATE INDEX idx_organization_members_userid ON organization_members ("userId");
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_organization_members_organizationid') THEN
    CREATE INDEX idx_organization_members_organizationid ON organization_members ("organizationId");
  END IF;
END$$;

-- Create invites table
CREATE TABLE IF NOT EXISTS invites (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  "organizationId" uuid NOT NULL,
  email varchar NOT NULL,
  role role_enum NOT NULL DEFAULT 'MEMBER',
  token varchar UNIQUE NOT NULL,
  "expiresAt" TIMESTAMP NOT NULL,
  "acceptedAt" TIMESTAMP NULL,
  "createdAt" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FK_invites_organizationId"
    FOREIGN KEY ("organizationId") REFERENCES organizations(id) ON DELETE CASCADE
);

-- Index for invites token
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_invites_token') THEN
    CREATE INDEX idx_invites_token ON invites (token);
  END IF;
END$$;

-- Add currentOrgId column to users if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'currentOrgId'
  ) THEN
    ALTER TABLE users ADD COLUMN "currentOrgId" uuid NULL;
  END IF;
END$$;
