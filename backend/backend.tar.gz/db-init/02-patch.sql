-- Ensure required columns exist after restoring from backup

-- Users: 2FA and session fields
ALTER TABLE IF EXISTS public.users ADD COLUMN IF NOT EXISTS "twoFactorSecret" text;
ALTER TABLE IF EXISTS public.users ADD COLUMN IF NOT EXISTS "twoFactorEnabled" boolean DEFAULT false;
ALTER TABLE IF EXISTS public.users ADD COLUMN IF NOT EXISTS "twoFactorBackupCodes" text[];
ALTER TABLE IF EXISTS public.users ADD COLUMN IF NOT EXISTS "twoFactorEnabledAt" timestamp;
ALTER TABLE IF EXISTS public.users ADD COLUMN IF NOT EXISTS "currentOrgId" uuid;

-- Tenants: Legal compliance fields (TR/FR/DE/US)
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "website" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "taxOffice" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "mersisNumber" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "kepAddress" varchar;

ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "siretNumber" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "sirenNumber" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "apeCode" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "tvaNumber" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "rcsNumber" varchar;

ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "steuernummer" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "umsatzsteuerID" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "handelsregisternummer" varchar;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "finanzamt" varchar;
-- Some deployments also require recording the managing director name
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "geschaeftsfuehrer" varchar;

ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "einNumber" varchar;
-- Align with entity: use taxId (not taxIDNumber)
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "taxId" varchar;
-- Align with entity: use businessLicenseNumber
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "businessLicenseNumber" varchar;
-- Align with entity: add stateOfIncorporation
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS "stateOfIncorporation" varchar;

-- Keep legacy columns if they already exist; do not drop them automatically to avoid data loss
-- (taxIDNumber, businessLicense, salesTaxNumber)
